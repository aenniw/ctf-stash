import React, { PureComponent } from 'react';
import { connect } from 'unistore/react';
import styled from 'styled-components';

import { actions } from '~/Store';

const AppWrapper = styled.div`
  display: inline-block;
  width: 100%;
`;

const Challenge = styled.div`
  display: inline-block;
  width: calc(50% - 100px);
  margin: 25px;
  padding: 25px;
  position: relative;
  background: #f0f0f0;
`;

const Category = styled.h1`
  display: inline-block;
  width: calc(100% - 50px);
  position: relative;
`;

const Name = styled.h2`
  display: inline-block;
  width: calc(100% - 50px);
  position: relative;
`;

const Description = styled.p`
  display: inline-block;
  width: calc(100% - 50px);
  position: relative;
`;

const Attachments = styled.div`
  display: inline-block;
  width: calc(100% - 50px);
  position: relative;
`;

const Separator = styled.div`
  width: 100%;
  height: 5px;
  background: black;
  margin-top: 25px;
  margin-bottom: 25px;
`;

function ChallengeCat({ data, cat }) {
  return (
    data.filter(ch => ch.name.includes(cat))
      .sort((a, b) => {
        if (a.value < b.value) return -1;
        if (a.value > b.value) return 1;
        return 0;
      })
      .map(ch => (
        <Challenge>
          <Category dangerouslySetInnerHTML={{ __html: ch.category }} />
          <Name dangerouslySetInnerHTML={{ __html: ch.name }} />
          <Description dangerouslySetInnerHTML={{ __html: ch.description }} />
          <Attachments>
            {
// eslint-disable-next-line prefer-template
                ch.files.map(f => f.split('/')[1]).map(f => <a href={'public/data/' + f}>{f}</a>)
            }
          </Attachments>
        </Challenge>
      ))
  );
}


class App extends PureComponent {
  componentDidMount() {
    this.props.loadData();
  }

  render() {
    const { isLoading, data = [] } = this.props;

    if (isLoading) {
      return 'Loading...';
    }

    return (
      <AppWrapper>
        <ChallengeCat data={data} cat="Practice" />
        <Separator />
        <ChallengeCat data={data} cat="1<sup>st</sup>" />
        <Separator />
        <ChallengeCat data={data} cat="2<sup>nd</sup>" />
      </AppWrapper>
    );
  }
}

export default connect(
  state => state,
  actions
)(App);
